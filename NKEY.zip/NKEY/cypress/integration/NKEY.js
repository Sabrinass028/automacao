describe('Teste NKEY', () => {
  it('Cadastro', () => {
    cy.visit('http://altoqi-dev-817989462.sa-east-1.elb.amazonaws.com/');
	cy.get('.bmeTmh').first().click();
	cy.get('#name').clear().type('sabrina5');
	cy.get('#lastname').clear().type('souza5 santos3');
	cy.get('#email').clear().type('sabrina23@sabrina1.com');
	cy.get('#password').clear().type('senha5');
	cy.get('#react-select-2-input').click();
	cy.get('.select__menu').first().click();
	cy.get('.dsAYSp').first().click();
	cy.get('#react-select-3-input').click();
	cy.get('.select__menu').first().click();
	cy.get('#react-select-4-input').click();
	cy.get('.select__menu').first().click();
	cy.get('#react-select-6-input').click();
	cy.get('.select__menu').first().click();
	cy.get('.jkuPDK').first().click();
	cy.get('#customLink').clear().type('urlTeste5');
	cy.fixture('images/teste.png').as('logo');
	cy.get('#inputFile').then(function (el) {
 
  const blob = Cypress.Blob.base64StringToBlob(this.logo, 'images/teste.png')

  const file = new File([blob], 'images/teste.png', { type: 'image/png' })
  const list = new DataTransfer()

  list.items.add(file)
  const myFileList = list.files

  el[0].files = myFileList
  el[0].dispatchEvent(new Event('change', { bubbles: true }))
})
	 
	 
	
	
  })
})
