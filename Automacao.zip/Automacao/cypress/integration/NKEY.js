describe('Teste NKEY', () => {
  it('Cadastro e Login realizaods com sucesso', () => {
    cy.visit('http://altoqi-dev-817989462.sa-east-1.elb.amazonaws.com/');
	//Click Fazer Cadastro
	cy.get('.bmeTmh').first().click();
	//Preenche Dados Básicos
	cy.get('#name').clear().type('Sabrina');
	cy.get('#lastname').clear().type('Souza Santos');
	var randomNumber = Math.random();
	cy.get('#email').clear().type('testesabrina'+ randomNumber +'@sabrina1.com');
	cy.get('#password').clear().type('senha5');
	cy.get('#react-select-2-input').click();
	cy.get('.select__menu').first().click();
	cy.wait(500);
	cy.get('.dsAYSp').first().click();
	//Preenche dados dos locais
	cy.get('#react-select-3-input').click();
	cy.wait(300);
	cy.get('.select__menu').first().click();	
	cy.wait(500);
	cy.get('#react-select-4-input').click();
	cy.wait(300);
	cy.get('.select__menu').first().click();
	cy.wait(500);
	cy.get('#react-select-6-input').click();
	cy.wait(300);
	cy.get('.select__menu').first().click();
	cy.get('.jkuPDK').first().click();
	//Preenche URL e Foto
	cy.get('#customLink').clear().type('urlTeste' + randomNumber);
	cy.fixture('/Teste.png').as('imagemTeste');
	cy.get('#inputFile').as('fileInput').attachFile('Teste.png');
	cy.wait(500);
	cy.get('.jkuPDK').first().click();
	//Preenche Dados Graduação
	cy.get('#level').clear().type('Graduação');
	cy.get('#area').clear().type('Engenharia Civil');
	cy.get('#institution').clear().type('Instituição de Ensino');
	cy.get('.jkuPDK').first().click();
	//Preenche dados de Ocupação
	cy.get('#office').clear().type('Analista QA');
	cy.get('#react-select-7-input').clear().type('Minha Empresa1');
	cy.get('#react-select-7-input').type('{enter}');	
	cy.get('.jkuPDK').first().click();
	cy.wait(500);
	//Finaliza Cadastro
	cy.get('.jkuPDK').first().click();
	cy.wait(500);
	//Checa se fez Login
	cy.get(".bmeTmh").should('be.visible');	
	



	
	
  })
})
